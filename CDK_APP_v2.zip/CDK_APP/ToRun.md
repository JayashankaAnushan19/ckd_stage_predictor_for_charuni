For User-----

run in cmd
```
pip install fastapi uvicorn joblib pandas
pip install scikit-learn==1.6.1
```


For Dev------
In terminal:
```
uvicorn main:app --reload
```


Open:
```
http://127.0.0.1:8000/
```